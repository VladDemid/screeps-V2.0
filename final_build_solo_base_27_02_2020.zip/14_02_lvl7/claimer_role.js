var my_room = "W15S39",
    target_room = "W16S38",
    functions = require("functions");
    
    
var roleClaimer = {

    run: function(creep) {
        // --Claimer logic start--
        
         if ((creep.room + "").substr(6,6) != target_room) {
                creep.say("🧲");
                functions.go_to(creep, target_room);
            } else if ((creep.room + "").substr(6,6) == target_room) {
                creep.say("🧲");
                if(creep.room.controller) {
                    
                        if(creep.claimController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(creep.room.controller);
                        }
                    
                }
            } 
        
        // --Claimer logic end--
        
    }
};

module.exports = roleClaimer;





var roleTower = {

    run: function(tower, enemy_found, tower_num, towers_count, enemy) {
        // --tower logic start--
        
        
        if (enemy && tower.store["energy"] >= 10) {
            
            
            // const healer_creep = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
            //     filter: (i) => i.body.toString().indexOf("HEAL") != -1 
            // });
            // const target = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            
            // const target_healer = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
            //     filter: function(object) {
            //         return object.getActiveBodyparts(HEAL) >= 1;
            //     }
            // });
            
            // if (enemy) {
                tower.attack(enemy);
            // }
            
        } else if (!enemy_found) {
            const low_creeps = tower.pos.findClosestByRange(FIND_MY_CREEPS, {
                filter: function(object) {
                    return object.hits < object.hitsMax;
                }
            });
            
            if (low_creeps) {
                tower.heal(low_creeps);
            } else if (tower_num == 0 && tower.store["energy"] > 600 && Game.time % 3 == 0) {
                const low_str = tower.room.find(FIND_STRUCTURES, {
                    filter: (i) => (i.structureType == "road" && i.hits <= (i.hitsMax - 800))
                                || (i.structureType == "constructedWall" && i.hits <= 5000)
                                || (i.structureType == "rampart" && i.hits <= 5000)
                                || (i.structureType != "rampart" && i.structureType != "constructedWall"
                                    && i.structureType != "road" && i.hits < (i.hitsMax - 800) 
                                    && i.hits <= 20000)
                });
                low_str.sort((a,b) => a.hits - b.hits);
                
                if (low_str[0]) {
                    tower.repair(low_str[0]);
                }
            } else if (tower_num == 1 && tower.store["energy"] > 600 && towers_count <= 2 && Game.time % 2 == 0) {
                const low_str = tower.room.find(FIND_STRUCTURES, {
                    filter: (i) => (i.structureType == "constructedWall" && i.hits <= 40000)
                                || (i.structureType == "rampart" && i.hits <= 40000)
                                || (i.structureType != "rampart" && i.structureType != "constructedWall"
                                    && i.structureType != "road" && i.hits < (i.hitsMax - 800))
                });
                low_str.sort((a,b) => a.hits - b.hits);
                
                if (low_str[0]) {
                    tower.repair(low_str[0]);
                }
            } else if (tower_num == 2 && tower.store["energy"] > 600 && Game.time % 2 == 0) {
                const low_str = tower.room.find(FIND_STRUCTURES, {
                    filter: (i) => (i.structureType == "constructedWall" && i.hits <= 60000)
                                || (i.structureType == "rampart" && i.hits <= 200000)
                                || (i.structureType != "rampart" && i.structureType != "constructedWall"
                                    && i.structureType != "road" && i.hits < (i.hitsMax - 800))
                });
                low_str.sort((a,b) => a.hits - b.hits);
                
                if (low_str[0]) {
                    tower.repair(low_str[0]);
                }
            } else if (tower_num == 3 && tower.store["energy"] > 600) {
                const low_str = tower.pos.findInRange(FIND_STRUCTURES, 10, {
                    filter: (i) => (i.structureType == "constructedWall" && i.hits <= 60000)
                                || (i.structureType == "rampart" && i.hits <= 900000)
                                // || (i.structureType != "rampart" && i.structureType != "constructedWall"
                                //     && i.structureType != "road" && i.hits < (i.hitsMax - 800))
                });
                low_str.sort((a,b) => a.hits - b.hits);
                
                if (low_str[0]) {
                    tower.repair(low_str[0]);
                }
            }
        } 
        
        // console.log("find_work_creep ", find_work_creep);
        
        
            
        // --tower logic end--
        
    }
};

module.exports = roleTower;



//убивать сначала хилеров


// var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
//         filter: (i) => i.structureType == STRUCTURE_STORAGE &&
//                       i.store[RESOURCE_ENERGY] < 500000
//     });
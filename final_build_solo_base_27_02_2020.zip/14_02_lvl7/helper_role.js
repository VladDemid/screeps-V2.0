var helper_spot_x = 32,
    helper_spot_y = 36; //место базирования

var roleHelper = {

    run: function(creep, extensions_energy, extensions_mass) {
        // --helper logic start--
        
        if (creep.carry.energy < 50) {creep.memory.have_energy = false;} //чтобы не ходить с 49 энергии
        if (creep.carry.energy == creep.carryCapacity) {creep.memory.have_energy = true;}
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] > 1000
        });
        
        var tower_low = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_TOWER &&
                              i.store[RESOURCE_ENERGY] < 700
            });
        
        if (!creep.memory.have_energy) {
            if (my_storage) {
                creep.say("📥");
                
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
                
                if (creep.carry.energy > 50) { //если одновременно новый спавн и "creep.memory.have_energy = false" то по пути на склад заполнять ext
                    const range_1_ext = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                        filter: (i) => i.structureType == STRUCTURE_EXTENSION &&
                                          i.store[RESOURCE_ENERGY] < i.store.energyCapacity
                        }); 
                    if  (range_1_ext && range_1_ext.length > 0) {
                        creep.transfer(range_1_ext[0], RESOURCE_ENERGY);
                    }
                }
            }
        } else if (creep.memory.have_energy) {
            creep.say("🧰");
            
            
            if (tower_low) {
                if(creep.transfer(tower_low, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower_low);
                }
            } else if (Game.spawns.Spawn1.store[RESOURCE_ENERGY] < 300) { 
                if (creep.transfer(Game.spawns['Spawn1'], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(Game.spawns['Spawn1']);
                }
            } else if (extensions_mass.length && extensions_mass[0].energy < extensions_mass[0].energyCapacity) {
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                }
                if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extensions_mass[0]);
                }
            } 
            
            
            else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.have_energy = false;
            } else {
                if (!creep.pos.isEqualTo(helper_spot_x, helper_spot_y)) {
                    creep.moveTo(helper_spot_x, helper_spot_y);
                }
            }
        }
        // --helper logic end--
        
        
        
    }
};

module.exports = roleHelper;



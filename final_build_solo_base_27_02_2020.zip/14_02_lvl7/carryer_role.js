var my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39",
    left_up_room = "W16S38",
    suicide_timer, //чтобы не уходили от базы подыхать в других румах
    escape_timer, //чтобы бежать на базу подыхать (если задержался у пустого source)
    target_room,
    
    link_to_id = "5e32f3e2e9baddae3aabb44c",
    link_from2_id = "5e37443cac61b8392bdf948b",
    functions = require("functions");

var roleCarryer = {
    
    run: function(creep, my_storage) {
        // --carryer logic start--
        
        if (creep.carry.energy == 0) {
            creep.memory.full = false;
        } else if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.full = true;
        } 
        
        if (creep.name.split('Carryer')[1] <= 1) {
            target_room = right_room;
            escape_timer = 30;
            // source_#
        } else if (creep.name.split('Carryer')[1] <= 2) {
            target_room = left_room;
            escape_timer = 40;
        } else {
            target_room = left_up_room;
            escape_timer = 80;
            
            
        }
        
        if (!creep.memory.full) {
            if (creep.pos.roomName != target_room ) {
                if (creep.ticksToLive > escape_timer) {
                    creep.say("🚪");
                    functions.go_to(creep, target_room);
                } else {
                    if (creep.pos.roomName == my_room ) {
                        creep.say("💀");
                        if (!creep.pos.isEqualTo(11,25)) {
                            creep.moveTo(11,25);
                        } else {creep.suicide();}
                    } else {
                        creep.say("💀");
                        functions.go_to(creep, my_room);
                    }
                }
            } else if (creep.pos.roomName == target_room) {
                
                const container_mass = creep.room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
                      container_mass.sort((a,b) => a.store.getFreeCapacity() - b.store.getFreeCapacity() ); 
                      
                if (creep.ticksToLive > escape_timer) {
                    if (container_mass[0]) {
                        creep.say("📥");
                        if(creep.withdraw(container_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(container_mass[0]);
                        } else {
                            creep.moveTo(container_mass[0]);
                        }
                    } else {
                        var sources = creep.room.find(FIND_SOURCES);
                        creep.moveTo(sources[0]);
                    }
                } else {
                    creep.say("💀");
                    functions.go_to(creep, my_room);
                }
            }
        } else if (creep.memory.full) {
            if (creep.pos.roomName != my_room) {
                
                creep.say("📦");
                functions.go_to(creep, my_room);
                //--------
                // if (creep.name.split('Carryer')[1] == 3) {
                //     creep.moveTo(35,32);
                // }
                //--------
                
                
            } else if (creep.pos.roomName == my_room) {
                
                // const near_link = creep.pos.findInRange(FIND_MY_STRUCTURES, 4,
                //         {filter: {structureType: STRUCTURE_LINK}})[0];
                        
                const near_links = creep.pos.findInRange(FIND_MY_STRUCTURES, 4,
                        {filter: {structureType: STRUCTURE_LINK}});
                near_links.sort((a,b) => a.store["energy"] - b.store["energy"]);
                        
                if (near_links[0] && near_links[0].id != link_to_id) {
                    if (near_links[0].store[RESOURCE_ENERGY] < 800) {
                        creep.say("🔹");
                        if(creep.transfer(near_links[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(near_links[0]);
                        }
                    } else {
                        creep.moveTo(near_links[0]);
                        creep.say("🔷⏱");
                    }
                } else if (my_storage && my_storage.store["energy"] < 700000) {
                    creep.say("📦");
                    if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } else {
                    creep.moveTo(25,25);
                }
                
            }
        }
        
        if (creep.store[RESOURCE_ENERGY] > 0 && ((creep.room + "").substr(6,6) != my_room) ) {
            
            range_3_str = creep.pos.findInRange(FIND_STRUCTURES, 3,{
                filter: (i) => i.hits < i.hitsMax &&
                                (i.structureType == STRUCTURE_CONTAINER || i.hits < 10000)
            })[0];
            if  (range_3_str) {
                creep.repair(range_3_str);
            }
        }
        
        
        
        // --carryer logic end--
        
    }
};

module.exports = roleCarryer;



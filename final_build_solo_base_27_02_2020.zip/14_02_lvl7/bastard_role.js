var bastard_spot_x = 34,
    bastard_spot_y = 34, //место базирования
    resourse_mass = ["ZH", "LO", "KO", "UH", "GO", "K", "energy"];
    
    
var roleBastard = {

    run: function(creep, container_mass, extensions_mass, towers_mass, enemy_found, 
                  link_to, link_help_need) {
        // --bastard logic start--
        
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
        
        var tomb1 = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store["energy"] > 50 
            }),
        
            
        
            my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] < 700000
            }),
            
            my_terminal = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_TERMINAL 
            });
        
            
        
        if (!creep.memory.full) {
            
            
            if (tomb1 && !enemy_found) {
                creep.say("⚰️");
                if(creep.withdraw(tomb1, "energy") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb1);
                }
            } else if (towers_mass.length && towers_mass[0].store[RESOURCE_ENERGY] < 800 && my_storage && my_storage.store[RESOURCE_ENERGY] > 0) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (link_to && link_to.store[RESOURCE_ENERGY] > 0 && link_help_need) {
                creep.say("🔷");
                if(creep.withdraw(link_to, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(link_to);
                }
            } else if (creep.store.getFreeCapacity() < creep.carryCapacity) {
                creep.memory.full = true;
            } else {
                creep.say("🔍");
                if (!creep.pos.isEqualTo(bastard_spot_x, bastard_spot_y)) { 
                    creep.moveTo(bastard_spot_x, bastard_spot_y);
                }
            }
            
        } else if (creep.memory.full) {
            creep.say("📤");
            
            if (towers_mass.length && towers_mass.length > 0 && towers_mass[0].store[RESOURCE_ENERGY] < 800) {
                creep.say("🔭⚡️");
                if(creep.transfer(towers_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(towers_mass[0]);
                }
            } else if (container_mass.length && container_mass[0].store[RESOURCE_ENERGY] < 2000) {
                creep.say("📒");   
                if(creep.transfer(container_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(container_mass[0]);
                }
            } else if (my_terminal && my_terminal.store[RESOURCE_ENERGY] < 20000) {
                creep.say("⚖️");   
                if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_terminal);
                }
            } else if (my_storage) {
                creep.say("📤");
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } 
            else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.full = false;
            } else {
                if (!creep.pos.isEqualTo(bastard_spot_x, bastard_spot_y)) { 
                    creep.moveTo(bastard_spot_x, bastard_spot_y);
                }
            }
        }
        
        // --bastard logic end--
        
    }
};

module.exports = roleBastard;



        
//         if(ruin1) {
//             if(creep.withdraw(ruin1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
//                 creep.moveTo(ruin1);
//             }
//         }


//FIND_DROPPED_RESOURCES
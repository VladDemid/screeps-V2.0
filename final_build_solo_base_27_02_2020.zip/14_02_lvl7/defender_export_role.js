var my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39",
    left_up_room = "W16S38",
    right_up_room = "W14S38",
    right2_room = "W13S39",
    defender_exp_spot_x,
    defender_exp_spot_y; //место базирования
    functions = require("functions");

var roleDefender_export = {

    run: function(creep) {
        // --defender_export logic start--
        var target_room;
        
        
        
        if (creep.name.split('Defender_export')[1] <= 1) {
            target_room = right_up_room;
            defender_exp_spot_x = 35;
            defender_exp_spot_y = 33;
        } else {
            target_room = right2_room;
            defender_exp_spot_x = 23;
            defender_exp_spot_y = 20;
        }
        
        
        
        if (creep.pos.roomName != target_room) {
            creep.say("🚪🚧");
                functions.go_to(creep, target_room);
        } else if (creep.pos.roomName == target_room) {
            const hostile = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            const enemy_building = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType != STRUCTURE_CONTROLLER 
                });
            const target_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);    
            
            
            
                
            // if(target) {
            //     creep.say("⚔️");
            //     if(creep.attack(target) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(target);
            //     } 
            // } else if (enemy_building) {
            //     creep.say("💣");
            //     if(creep.attack(enemy_building) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(enemy_building);
            //     }  
            // } else {
            //     creep.say("🚧");
            //     var sources = creep.room.find(FIND_SOURCES);
            //     if (!creep.pos.isNearTo(sources[0])) {
            //         creep.moveTo(sources[0]);
            //     } 
            // } 
        }
        
        
          
        
        // --defender_export logic end--
        
    }
};

module.exports = roleDefender_export;



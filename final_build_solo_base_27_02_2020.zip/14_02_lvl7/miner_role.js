var miner_spot_x = 38,
    miner_spot_y = 41,
    link_from_id = "5e32f21e0f27bd4c00b3861e",
    link_to_id = "5e32f3e2e9baddae3aabb44c";
    
    
var roleMiner = {

    run: function(creep, spawning_lvl, extensions_energy, extensions_mass, containers_energy, container_mass, my_storage, help_need, building_need) {
        // --miner logic start--
        
        if (creep.carry.energy == 0) {
            creep.memory.mining = true;
            creep.memory.building = false;
            creep.memory.carry = false;
            
        } else if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.mining = false;
            creep.memory.building = true;
            creep.memory.carry = true;
            
        }     
        var closest_build = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        
        var near_link = creep.pos.findInRange(FIND_MY_STRUCTURES, 5,
            {filter: {structureType: STRUCTURE_LINK}})[0];
        
        var container_With_Energy = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_CONTAINER &&
                           i.store[RESOURCE_ENERGY] > 0
        });
            // console.log(my_storage.store[RESOURCE_ENERGY]);
        if (creep.memory.mining) {
            if (closest_build && container_With_Energy && building_need) {
                creep.say("📥");
                if(creep.withdraw(container_With_Energy, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(container_With_Energy);
                }
            } else if (closest_build && my_storage.store[RESOURCE_ENERGY] > 0 && building_need) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else {
                creep.say("⛏");
                if (creep.carry.energy < creep.carryCapacity) {
                    var sources = creep.room.find(FIND_SOURCES);
                    
                    var dest_mining = 0;
                    if (creep.name.split('Miner')[1] <= 1) {
                        dest_mining = 1;
                    }
                    
                    if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(sources[dest_mining]);
                    }
                    
                } 
            }
            
        // транспортировка для спавна
        } else if (creep.room.energyAvailable < creep.room.energyCapacityAvailable && help_need) {
            if (Game.spawns.Spawn1.store[RESOURCE_ENERGY] < 300) { 
                creep.say("🚛");
                if (creep.transfer(Game.spawns['Spawn1'], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(Game.spawns['Spawn1']);
                }
            } else if (extensions_mass.length && extensions_mass[0].energy < extensions_mass[0].energyCapacity) {
                // console.log("extensions energy low");
                creep.say("📀");
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                }
                if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extensions_mass[0]);
                } 
            } 
        // строительство
        } else if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES) && building_need) {
            creep.say("🧱");
            const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
            if(creep.build(target) == ERR_NOT_IN_RANGE) {
                creep.moveTo(target);
            }   else {creep.build(target);} //?????
        //заполнение контейнеров
        } else if (container_mass.length && container_mass[0].store[RESOURCE_ENERGY] < container_mass[0].store.getCapacity()) {
            creep.say("📒");   
            //ext??? containers!!!
            const target_near_ext = creep.pos.findClosestByRange(FIND_STRUCTURES,   
                {filter: {structureType: STRUCTURE_CONTAINER}});
            if(target_near_ext && target_near_ext.store[RESOURCE_ENERGY] < target_near_ext.store.getCapacity()) {
                    if(creep.transfer(target_near_ext, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_near_ext);
                    } 
            } else { 
                if(creep.transfer(container_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(container_mass[0]);
                } 
            }
            
        } 
        else if (near_link && near_link.id == link_from_id) {
            if (near_link.store[RESOURCE_ENERGY] < 800) {
                creep.say("🔷");
                if(creep.transfer(near_link, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(near_link);
                }
            } else {
                creep.say("🔷⏱");
            }
        }
        
        else if (my_storage && my_storage.store[RESOURCE_ENERGY] < 700000) { //класть ложить на склад до 700к энергии
            creep.say("📒");
            if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                creep.moveTo(my_storage);
            }
        } else if (creep.carry.energy < creep.carryCapacity) {
            creep.memory.mining = true;
        
        } else {
            creep.say("🚬");
            creep.moveTo(miner_spot_x, miner_spot_y);
        }
        // console.log(extensions_energy);
        // --miner logic end--
        
    }
};

module.exports = roleMiner;




var roleBuilder = {

    run: function(creep) {
        // --builder_t2 logic start--
        
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                          i.store[RESOURCE_ENERGY] > 20000
        }),
            closest_build = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        
        if (creep.store.getFreeCapacity() == creep.store.getCapacity()) {
            creep.memory.full = false;
        } else if (creep.store.getFreeCapacity() == 0) {
            creep.memory.full = true;
        } 
        
        if (creep.memory.full && closest_build) {
            creep.say("🧱");
            if (closest_build) {
                if(creep.build(closest_build) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(closest_build);
                }
            }
        } else if (!creep.memory.full && my_storage) {
            creep.say("📥");
            if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                creep.moveTo(my_storage);
            }
        } else if (creep.carry.energy < creep.carryCapacity)  {
            creep.memory.building = false;
        } else {
            creep.say("🚬");
            creep.moveTo(35,27);
        }
        
        // --builder_t2 logic end--
        
    }
};

module.exports = roleBuilder;




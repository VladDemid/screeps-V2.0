var import_x = 40,
    import_y = 22,
    my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39",
    suicide_timer = 98, //чтобы подыхали у базы (+ ресы)
    target_room;
    
var roleMiner_import = {

    run: function(creep) {
        // --miner_import logic start--
        
        if (creep.carry.energy == 0) {
            creep.memory.mining = true;
        } else if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.mining = false;
        }  
        
        var full_HP;
        if (creep.hits == creep.hitsMax) {
            full_HP = 1;
        } else {
            full_HP = 0;
        }
            
        var target_room;
        if (creep.name.split('Miner_import')[1] <= 4) {
            target_room = right_room;
        } else {
            target_room = left_room;
        }
        
        if (full_HP) {
            if (creep.memory.mining) {
                    if ((creep.room + "").substr(6,6) == my_room) {
                    creep.say("🚪");
                    const route = Game.map.findRoute(creep.room, target_room);
                    if(route.length > 0) {
                        const exit = creep.pos.findClosestByRange(route[0].exit);
                        creep.moveTo(exit);
                    }
                    if (creep.ticksToLive < suicide_timer) { 
                        creep.suicide(); 
                    }
                } else if ((creep.room + "").substr(6,6) == target_room) {
                    creep.say("⛏");
                    if (creep.carry.energy < creep.carryCapacity) {
                        var sources = creep.room.find(FIND_SOURCES);
                        
                        if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(sources[0]);
                        }
                    } 
                } 
            } else if (!creep.memory.mining) {
                
                if ((creep.room + "").substr(6,6) == target_room) {
                    
                    var tower_exp = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == STRUCTURE_TOWER &&
                                       i.store[RESOURCE_ENERGY] < 810
                    });
                    
                    const range_3_str = creep.pos.findInRange(FIND_STRUCTURES, 3, { //найти hits - min
                        filter: object => object.hits < object.hitsMax 
                    });
                    if  (range_3_str) {
                        // console.log(range_3_str[0].hits);
                        for (var z = 0; z < range_3_str.length;z++) {
                            if (range_3_str[z].hits < range_3_str[z].hitsMax && range_3_str[z].hits < 10000) {
                                creep.repair(range_3_str[z]);
                            }
                        }
                    }
                    
                    var low_hits_build = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.hits < 10000 && i.hits < i.hitsMax && i.hitsMax > 5000
                    });
                    
                    if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
                        creep.say("🧱");
                        const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                        if(creep.build(target) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(target);
                        }
                    } else if (low_hits_build) {
                        creep.say("🧱");
                        if(creep.repair(low_hits_build) == ERR_NOT_IN_RANGE) {
                             creep.moveTo(low_hits_build);
                        }
                        
                    } else if (tower_exp) {
                        if(creep.transfer(tower_exp, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(tower_exp);
                        }
                    } else {
                        creep.say("📦");
                        const route = Game.map.findRoute(creep.room, my_room);
                        if(route.length > 0) {
                            const exit = creep.pos.findClosestByRange(route[0].exit);
                            creep.moveTo(exit);
                        }
                    }
                    
                } else if ((creep.room + "").substr(6,6) == my_room) {
                    var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                                       i.store[RESOURCE_ENERGY] < 400000 //класть ложить на склад до 400к энергии
                    });
                    if (my_storage) {
                        creep.say("📦");
                        if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(my_storage);
                        }
                    } else if (!my_storage) {
                        creep.say("⏱");
                        creep.moveTo(44,35);
                    }
                    
                }
                
            }
        } else {
            creep.say("💊");
            if ((creep.room + "").substr(6,6) == my_room) {
                creep.moveTo(34,22); //heal spot
            } else if ((creep.room + "").substr(6,6) == target_room) {
                const route = Game.map.findRoute(creep.room, my_room);
                if(route.length > 0) {
                    const exit = creep.pos.findClosestByRange(route[0].exit);
                    creep.moveTo(exit);
                }
            }
            
        }  
        // if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
        //     creep.say("🧱");
        //     const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        //     if(creep.build(target) == ERR_NOT_IN_RANGE) {
        //         creep.moveTo(target);
        //     } 
        
        
            
        // --miner_import logic end--
        
    }
};

module.exports = roleMiner_import;


var start_room = "W15S39",
    target_room = "W13S38",
    now_going_room,
    scout_spot_x = 11,
    scout_spot_y = 47, //место базирования
    
    functions = require("functions");

var roleScout = {

    run: function(creep) {
        // --Scout logic start--
        var my_room = functions.room_name(creep.room);
        // console.log(my_room);
        if (my_room == "W13S39") {
            creep.moveTo(19,0);
        } else if (my_room == target_room) {
            const target_ramp = Game.getObjectById("5df656e3161da69558af03ac"),
                  target_enemy_spawn = Game.getObjectById("5de84cf5fed643ea29ad66f1"),
                  enemy = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                  
            if (target_ramp && creep.attack(target_ramp) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target_ramp);
            } else if (!target_ramp && creep.attack(target_enemy_spawn) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target_enemy_spawn);
            } else if (!target_ramp && !target_enemy_spawn && enemy) {
                if(creep.attack(enemy) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(enemy);
                }
            } 
            
            // var enemy_buildings = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
            //     filter: (i) => i.structureType == STRUCTURE_EXTENSION 
            //                  && i.store[RESOURCE_ENERGY] > 1000
            // });
             
            
            //  if (creep.attack(target_tower2) == ERR_NOT_IN_RANGE) {
            //     creep.moveTo(target_tower2);
            // } 
            creep.say("💣");
        } else {
            now_going_room = functions.go_to_room(creep, my_room, target_room);
            const route = Game.map.findRoute(creep.room, now_going_room);
            if(route.length > 0) {
                const exit = creep.pos.findClosestByRange(route[0].exit);
                creep.moveTo(exit);
            }
        }
        // --Scout logic end--
        
    }
};

module.exports = roleScout;



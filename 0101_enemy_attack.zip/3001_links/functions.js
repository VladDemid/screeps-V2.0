var cpu_avg = 0,
    cpu_i = 1;

module.exports.create_name = function create_name(role, max_role_creeps) {
    var export_name;
    do {
        export_name = role + this.random_Integer(1, max_role_creeps);
    } while (Game.creeps[export_name]);
    return export_name;
}

module.exports.show_time = function show_time() {
    console.log('             -- ', Date().split('2020')[1].split('GMT')[0], " --");
}

// CPU на каждую профессию

module.exports.random_Integer = function random_Integer(min, max) {
  // случайное число от min до (max+1)
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}    

module.exports.energy_information = function energy_information() {
  console.log("spawn: ", );
  console.log(extensions_energy, " energy in ", extensions_mass.length, " extensions");
}  


module.exports.cpu_used = function cpu_used() {
    const n = 20;
    // 
    cpu_avg = cpu_avg + Game.cpu.getUsed(); 
    if (cpu_i >= n) {
        console.log('last 20 ticks cpu_avg usage: '+ (cpu_avg/n).toFixed(2));
        cpu_i = 1;
        cpu_avg = 0;
    }
    cpu_i++;
}

module.exports.room_name = function room_name(room_raw) {
    var room = (room_raw + "").substr(6,6);
    return(room);
}

module.exports.go_to_room = function room_name(creep, this_room, target_room) {
    var horizontal_now = this_room.substr(1,2),
        horizontal_target = target_room.substr(1,2),
        vertical_now = this_room.substr(4,2),
        vertical_target = target_room.substr(4,2),
        now_going_vert, now_going_horiz,
        now_going_room;
        
    if (horizontal_now > horizontal_target) {
        now_going_horiz = Number(horizontal_now) - 1;
        now_going_room = "W"+now_going_horiz+"S"+vertical_now;
        creep.say("➡️");
    } else if (horizontal_now < horizontal_target) {
        now_going_horiz = Number(horizontal_now) + 1;
        now_going_room = "W"+now_going_horiz+"S"+vertical_now;
        creep.say("⬅️");
    } else if (horizontal_now == horizontal_target) {
        if (vertical_now > vertical_target) {
            now_going_vert = Number(vertical_now) - 1;
            now_going_room = "W"+horizontal_now+"S"+now_going_vert;
            creep.say("⬆️");
        } else if (vertical_now < vertical_target) {
            now_going_vert = Number(vertical_now) + 1;
            now_going_room = "W"+horizontal_now+"S"+now_going_vert;
            creep.say("⬇️");
        }
    }
    return(now_going_room);
}

module.exports.spawn_creep = function spawn_creep(role, max_role_creeps, spawn_lvl) {
    if (spawn_lvl == 1) {
        console.log("1 spawn lvl");
        switch (role) {
            case "Miner":
                var temp_name = this.create_name("Miner", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,CARRY,CARRY,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner";
                break;
            case "Defender":
                var temp_name = this.create_name("Defender", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([TOUGH,TOUGH,TOUGH,TOUGH,MOVE,MOVE,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = "defender";
                break;
            case "Upgrader":
                var temp_name = this.create_name("Upgrader", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK, WORK, CARRY, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "upgrader";
                break;
            case "Fixer":
                var temp_name = this.create_name("Fixer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "fixer";
                break;
            default:
                console.log("spawning error!!");
                break;
        }
    } else if (spawn_lvl == 2) {
        console.log("2 spawn lvl");
        switch (role) {
            case "Miner":
                var temp_name = this.create_name("Miner", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner";
                break;
            case "Defender":
                var temp_name = this.create_name("Defender", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([TOUGH,TOUGH,TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = "defender";
                break;
            case "Upgrader":
                var temp_name = this.create_name("Upgrader", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,CARRY,CARRY,CARRY,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "upgrader";
                break;
            case "Fixer":
                var temp_name = this.create_name("Fixer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "fixer";
                break;
            case "Healer":
                var temp_name = this.create_name("Healer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([MOVE,MOVE,HEAL], temp_name);
                Game.creeps[temp_name].memory.role = "healer";
                break;
            default:
                console.log("spawning error!!");
                break;
        }
    } else if (spawn_lvl == 3) { 
        console.log("3 spawn lvl");
        switch (role) {
            case "Miner":
                var temp_name = this.create_name("Miner", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner";
                break;
            case "Defender":
                var temp_name = this.create_name("Defender", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([TOUGH,TOUGH,TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = "defender";
                break;
            case "Upgrader":
                var temp_name = this.create_name("Upgrader", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "upgrader";
                break;
            case "Fixer":
                var temp_name = this.create_name("Fixer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "fixer";
                break;
            case "Healer":
                var temp_name = this.create_name("Healer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([MOVE,MOVE,HEAL], temp_name);
                Game.creeps[temp_name].memory.role = "healer";
                break;
            case "Bastard":
                var temp_name = this.create_name("Bastard", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "bastard";
                break;
            case "Miner_import":
                var temp_name = this.create_name("Miner_import", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner_import";
                break;
            default:
                console.log("spawning error!!");
                break;
        }
    } else if (spawn_lvl == 4) { //11500 energy
        console.log("4 spawn lvl");
        switch (role) {
            case "Miner":
                var temp_name = this.create_name("Miner", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner";
                break;
            case "Defender":
                var temp_name = this.create_name("Defender", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,
                    MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = "defender";
                break;
            case "Upgrader":
                var temp_name = this.create_name("Upgrader", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "upgrader";
                break;
            case "Fixer":
                var temp_name = this.create_name("Fixer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "fixer";
                break;
            case "Healer":
                var temp_name = this.create_name("Healer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([MOVE,MOVE,HEAL], temp_name);
                Game.creeps[temp_name].memory.role = "healer";
                break;
            case "Bastard":
                var temp_name = this.create_name("Bastard", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "bastard";
                break;
            case "Miner_import":
                var temp_name = this.create_name("Miner_import", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "miner_import";
                break;
            case "Claimer":
                var temp_name = this.create_name("Claimer", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([CLAIM,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "claimer";
                break;
            case "Upgrader_export":
                var temp_name = this.create_name("Upgrader_export", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([WORK,CARRY,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "upgrader_export";
                break;
            case "Defender_export":
                var temp_name = this.create_name("Defender_export", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,
                    TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = "defender_export";
                break;
            case "Helper":
                var temp_name = this.create_name("Helper", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "helper";
                break;
            case "Scout":
                var temp_name = this.create_name("Scout", max_role_creeps);
                Game.spawns.Spawn1.spawnCreep([ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,ATTACK,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = "scout";
                break;
            default:
                console.log("spawning error!!");
                break;
        }
    } else {
        console.log(console.log("wrong spawning lvl"));
    }
    
}




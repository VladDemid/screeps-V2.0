var helper_spot_x = 31,
    helper_spot_y = 44; //место базирования

var roleHelper = {

    run: function(creep, extensions_energy, extensions_mass) {
        // --helper logic start--
        
        if (creep.carry.energy == 0) {creep.memory.have_energy = false;}
        if (creep.carry.energy == creep.carryCapacity) {creep.memory.have_energy = true;}
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] > 1000
        });
        
        if (!creep.memory.have_energy) {
            if (my_storage) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            }
        } else if (creep.memory.have_energy) {
            creep.say("🧰");
            var near_ext = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                filter: (i) => i.structureType == STRUCTURE_EXTENSION &&
                               i.store.getFreeCapacity(RESOURCE_ENERGY) > 0
            });
            if (near_ext) {
                if(creep.transfer(near_ext, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(near_ext);
                } 
            } else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.have_energy = false;
            } else {
                creep.moveTo(helper_spot_x, helper_spot_y);
            }
        }
        // --helper logic end--
        
    }
};

module.exports = roleHelper;



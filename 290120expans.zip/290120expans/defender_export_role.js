var my_room = "W15S39",
    right_room = "W14S39",
    defender_exp_spot_x = 13,
    defender_exp_spot_y = 5; //место базирования

var roleDefender_export = {

    run: function(creep) {
        // --defender_export logic start--
        
        
        if ((creep.room + "").substr(6,6) == my_room) {
            creep.say("🚪🚧");
                const route = Game.map.findRoute(creep.room, right_room);
                if(route.length > 0) {
                    const exit = creep.pos.findClosestByRange(route[0].exit);
                    creep.moveTo(exit);
                }
        } else if ((creep.room + "").substr(6,6) == right_room) {
            const target = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(target) {
                creep.say("⚔️");
                if(creep.attack(target) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target);
                } 
            } else {
                creep.moveTo(defender_exp_spot_x, defender_exp_spot_y);
                creep.say("🚧");
            } 
        }
        
        
          
        
        // --defender_export logic end--
        
    }
};

module.exports = roleDefender_export;



var bastard_spot_x = 30,
    bastard_spot_y = 35; //место базирования

var roleBastard = {

    run: function(creep, container_mass, extensions_mass, towers_mass) {
        // --bastard logic start--
        
        if (creep.carry.energy == 0) {creep.memory.have_energy = false;}
        if (creep.carry.energy == creep.carryCapacity) {creep.memory.have_energy = true;}
        
        var tomb1 = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_ENERGY] > 0 
        });
        var ruin1 = creep.pos.findClosestByRange(FIND_RUINS, {
            filter: object => object.store[RESOURCE_ENERGY] > 0 
        });
        
        var ruin1 = creep.pos.findClosestByRange(FIND_RUINS, {
            filter: object => object.store[RESOURCE_ENERGY] > 0 
        });
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] < 500000
        });
        
        var drop1 = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES);
        // console.log(my_storage.pos);
        
        if (!creep.memory.have_energy) {
            if (tomb1) {
                creep.say("⚰️");
                if(creep.withdraw(tomb1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb1);
                }
            } else if (drop1) {
                creep.say("💎");
                if(creep.pickup(drop1) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(drop1);
                }
            } else if (ruin1) {
                creep.say("🏺");
                if(creep.withdraw(ruin1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(ruin1);
                }
            } else if (my_storage && creep.carry.energy < creep.carryCapacity && creep.carry.energy > 0) {
                creep.say("📤");
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (towers_mass.length && towers_mass[0].store[RESOURCE_ENERGY] < 1000 && my_storage && my_storage.store[RESOURCE_ENERGY] > 0) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else {
                creep.say("🔍");
                creep.moveTo(bastard_spot_x, bastard_spot_y);
            }
            // else {
            //     creep.say("📥");
            //     if(creep.withdraw(container_mass[container_mass.length - 1], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(container_mass[container_mass.length - 1]);
            //     }
            // }
        } else if (creep.memory.have_energy) {
            creep.say("📤");
            if (towers_mass.length && towers_mass.length > 0 && towers_mass[0].store[RESOURCE_ENERGY] < 1000) {
                if(creep.transfer(towers_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(towers_mass[0]);
                }
            } else if (creep.room.energyAvailable < creep.room.energyCapacityAvailable /*&& !(creep.name.split('Miner')[1] % 6 == 0)*/) {
                if (Game.spawns.Spawn1.store[RESOURCE_ENERGY] < 300) { 
                    if (creep.transfer(Game.spawns['Spawn1'], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(Game.spawns['Spawn1']);
                    }
                } else if (extensions_mass.length && extensions_mass[0].energy < extensions_mass[0].energyCapacity) {
                    // console.log("extensions energy low");
                    const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                    if  (range_1_str) {
                        for (var y = 0; y < range_1_str.length;y++) {
                            if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                                creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                                creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                            }
                        }
                    } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(extensions_mass[0]);
                    }
                    if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                    } 
                } 
            } 
            else if (my_storage) {
                creep.say("📤");
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } 
            else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.have_energy = false;
            } else {
                creep.moveTo(bastard_spot_x, bastard_spot_y);
            }
        }
        
        // --bastard logic end--
        
    }
};

module.exports = roleBastard;



        
//         if(ruin1) {
//             if(creep.withdraw(ruin1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
//                 creep.moveTo(ruin1);
//             }
//         }


//FIND_DROPPED_RESOURCES
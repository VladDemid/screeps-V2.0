

var roleUpgrader = {

    run: function(creep) {
        // --upgrader logic start--
        creep.say("🔋");
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] > 3000
        });
        
        if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.upgrading_now = true;
        }
        if (creep.carry.energy == 0) {
            creep.memory.upgrading_now = false;
        }
        var sources = Game.spawns['Spawn1'].room.find(FIND_SOURCES);
        
        var dest_mining = 0; //откуда сосать
        if (creep.name.split('Upgrader')[1] % 2 == 0) {
            dest_mining = 1;
        }
        
        if (creep.carry.energy < creep.carryCapacity && creep.memory.upgrading_now == false) {
            if (my_storage) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else {
                if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(sources[dest_mining])
                }
            }
            
        } else {
            var controller = Game.spawns['Spawn1'].room.controller;
            if (creep.upgradeController(controller) == ERR_NOT_IN_RANGE) {
                creep.moveTo(controller);
            }
        }
        
        // --upgrader logic end--
        
    }
};

module.exports = roleUpgrader;




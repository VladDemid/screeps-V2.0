var import_x = 40,
    import_y = 22,
    my_room = "W15S39",
    right_room = "W14S39";
    
var roleMiner_import = {

    run: function(creep) {
        // --miner_import logic start--
        if (creep.carry.energy == 0) {
            creep.memory.mining = true;
            creep.memory.building = false;
            creep.memory.carry = false;
            
        } else if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.mining = false;
            creep.memory.building = true;
            creep.memory.carry = true;
            
        }  
        if (creep.memory.mining) {
                if ((creep.room + "").substr(6,6) == my_room) {
                creep.say("🚪");
                const route = Game.map.findRoute(creep.room, right_room);
                if(route.length > 0) {
                    const exit = creep.pos.findClosestByRange(route[0].exit);
                    creep.moveTo(exit);
                }
            } else if ((creep.room + "").substr(6,6) == right_room) {
                creep.say("⛏");
                if (creep.carry.energy < creep.carryCapacity) {
                    var sources = creep.room.find(FIND_SOURCES);
                    
                    if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(sources[0]);
                    }
                } 
            } 
        } else if (!creep.memory.mining) {
            
            if ((creep.room + "").substr(6,6) != my_room) {
                
                const range_3_str = creep.pos.findInRange(FIND_STRUCTURES, 3, { //найти hits - min
                    filter: object => object.hits < object.hitsMax 
                });
                if  (range_3_str) {
                    // console.log(range_3_str[0].hits);
                    for (var z = 0; z < range_3_str.length;z++) {
                        if (range_3_str[z].hits < range_3_str[z].hitsMax && range_3_str[z].hits < 10000) {
                            creep.repair(range_3_str[z]);
                        }
                    }
                }
                
                if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
                    creep.say("🧱");
                    const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                    if(creep.build(target) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target);
                    }
                } else {
                    creep.say("📦");
                    const route = Game.map.findRoute(creep.room, my_room);
                    if(route.length > 0) {
                        const exit = creep.pos.findClosestByRange(route[0].exit);
                        creep.moveTo(exit);
                    }
                }
                
            } else if ((creep.room + "").substr(6,6) == my_room) {
                var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                                   i.store[RESOURCE_ENERGY] < 300000
                });
                if (my_storage) {
                    creep.say("📦");
                    if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } else if (!my_storage) {
                    creep.say("⏱");
                    creep.moveTo(44,35);
                }
                
            }
            
        }
        
        // if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
        //     creep.say("🧱");
        //     const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        //     if(creep.build(target) == ERR_NOT_IN_RANGE) {
        //         creep.moveTo(target);
        //     } 
        
        
            
        // --miner_import logic end--
        
    }
};

module.exports = roleMiner_import;


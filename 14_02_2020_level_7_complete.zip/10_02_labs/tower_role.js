

var roleTower = {

    run: function(tower, enemy_found) {
        // --tower logic start--
        
        
        
        if (enemy_found) {
            Game.notify('We were attacked ', 2);
            // const healer_creep = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
            //     filter: (i) => i.body.toString().indexOf("HEAL") != -1 
            // });
            const target = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            const target_healer = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
                filter: function(object) {
                    return object.getActiveBodyparts(HEAL) >= 1;
                }
            });
            
            if (target) {
                tower.attack(target);
            }
            
        } else if (!enemy_found) {
            const low_creeps = tower.pos.findClosestByRange(FIND_MY_CREEPS, {
                filter: function(object) {
                    return object.hits < object.hitsMax;
                }
            });
            
            const low_hits_7R = tower.pos.findInRange(FIND_MY_STRUCTURES, 7, {
                filter: (i) => i.hitsMax > 5000 &&
                              i.hits < i.hitsMax && i.hits < 50000
            });
            
            if (low_creeps) {
                tower.heal(low_creeps);
            } else if (low_hits_7R.length > 0) {
                tower.repair(low_hits_7R[0]);
            }
        } 
        
        // console.log("find_work_creep ", find_work_creep);
        
        
        // --tower logic end--
        
    }
};

module.exports = roleTower;



//убивать сначала хилеров


// var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
//         filter: (i) => i.structureType == STRUCTURE_STORAGE &&
//                       i.store[RESOURCE_ENERGY] < 500000
//     });
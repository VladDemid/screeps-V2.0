var import_x = 40,
    import_y = 22,
    my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39",
    left_up_room = "W16S38",
    suicide_timer, //чтобы не уходили от базы подыхать в других румах
    escape_timer, //чтобы бежать на базу подыхать (если задержался у пустого source)
    target_room,
    
    link_from2_id = "5e37443cac61b8392bdf948b",
    functions = require("functions");
    
var roleMiner_import = {

    run: function(creep) {
        // --miner_import logic start--
        
        if (creep.carry.energy == 0) {
            creep.memory.mining = true;
        } else if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.mining = false;
        }  
        
        var full_HP;
        if (creep.hits == creep.hitsMax) {
            full_HP = 1;
        } else {
            full_HP = 0;
        }
        
        var target_room,
            dest_mining = 0;
        if (creep.name.split('Miner_import')[1] <= 1) {
            target_room = right_room;
            escape_timer = 30;
            suicide_timer = 98;
            // source_#
        } else if (creep.name.split('Miner_import')[1] <= 2) {
            target_room = left_room;
            escape_timer = 40;
            suicide_timer = 125;
        } else {
            target_room = left_up_room;
            escape_timer = 75;
            suicide_timer = 150;
            dest_mining = 1;
            if (creep.name.split('Miner_import')[1] == 4) {
                dest_mining = 0;
            }
        }
        
        if (full_HP) {
            if (creep.memory.mining) {
                if ((creep.room + "").substr(6,6) != target_room ) {
                    if (creep.ticksToLive > suicide_timer) {
                        creep.say("🚪");
                        functions.go_to(creep, target_room);
                    } else {
                        if ((creep.room + "").substr(6,6) == my_room ) {
                            creep.suicide();
                        } else {
                            functions.go_to(creep, my_room);
                        }
                    }
                } else if ((creep.room + "").substr(6,6) == target_room) {
                    creep.say("⛏");
                    // if (creep.ticksToLive > escape_timer) { //выбираться если подыхает
                        if (creep.carry.energy < creep.carryCapacity) {
                            var sources = creep.room.find(FIND_SOURCES);
                            if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                                creep.moveTo(sources[dest_mining]);
                            } else if (creep.harvest(sources[dest_mining]) == ERR_NOT_ENOUGH_RESOURCES) {
                                // creep.moveTo(sources[dest_mining]);
                                if (!(Math.abs(creep.pos.x - sources[dest_mining].pos.x) <= 1 
                                && Math.abs(creep.pos.y - sources[dest_mining].pos.y) <= 1)) {
                                    creep.moveTo(sources[dest_mining]);
                                }
                            }
                        } 
                    // } else {
                    //     functions.go_to(creep, my_room);
                    // }
                } 
                
                
            } else if (!creep.memory.mining) {
                if ((creep.room + "").substr(6,6) != my_room) {
                    var tower_exp = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == STRUCTURE_TOWER &&
                                       i.store[RESOURCE_ENERGY] < 810
                    });
                    
                    const near_container= creep.pos.findInRange(FIND_STRUCTURES, 1, {
                        filter: (i) => i.structureType == STRUCTURE_CONTAINER &&
                                       i.store[RESOURCE_ENERGY] < 2000
                    });
                    
                    const range_3_str = creep.pos.findInRange(FIND_STRUCTURES, 3, { //найти hits - min
                        filter: object => object.hits < object.hitsMax 
                    });
                    if  (range_3_str) {
                        // console.log(range_3_str[0].hits);
                        for (var z = 0; z < range_3_str.length;z++) {
                            if ((range_3_str[z].hits < range_3_str[z].hitsMax && range_3_str[z].hits < 10000) 
                            || range_3_str[z].structureType == STRUCTURE_CONTAINER) {
                                creep.repair(range_3_str[z]);
                            }
                        }
                    }
                    
                    range_3_str2 = creep.pos.findInRange(FIND_STRUCTURES, 3,{
                        filter: (i) => i.hits < i.hitsMax &&
                                      (i.structureType == STRUCTURE_CONTAINER || i.hits < 10000)
                    })[0];
                    
                    
                    if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
                        creep.say("🧱");
                        const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                        if(creep.build(target) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(target);
                        }
                    } else if (range_3_str2) {
                        creep.say("🧱");
                        if(creep.repair(range_3_str2) == ERR_NOT_IN_RANGE) {
                             creep.moveTo(range_3_str2);
                        }
                    } else if (tower_exp) {
                        if(creep.transfer(tower_exp, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(tower_exp);
                        }
                    } else if (near_container[0]) {
                        // console.log(near_container[0].store[RESOURCE_ENERGY]);
                        creep.say("📦");
                        creep.transfer(near_container[0], RESOURCE_ENERGY);
                    } else {
                        var sources = creep.room.find(FIND_SOURCES);
                        creep.say("⏱");
                        creep.moveTo(sources[dest_mining])
                        // functions.go_to(creep, my_room);
                    }
                    
                } 
                
                // else if ((creep.room + "").substr(6,6) == my_room) {
                //     var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                //         filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                //                       i.store[RESOURCE_ENERGY] < 400000 //класть ложить на склад до 400к энергии
                //     });
                    
                //     var near_link = creep.pos.findInRange(FIND_MY_STRUCTURES, 5,
                //         {filter: {structureType: STRUCTURE_LINK}})[0];
                //     if (near_link && near_link.id == link_from2_id) {
                //         if (near_link.store[RESOURCE_ENERGY] < 800) {
                //             creep.say("🔷");
                //             if(creep.transfer(near_link, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                //                 creep.moveTo(near_link);
                //             } 
                //         } else {
                //             creep.say("🔷⏱");
                //         }
                //     }
                //     else if (my_storage) {
                //         creep.say("📦");
                //         if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                //             creep.moveTo(my_storage);
                //         }
                //     } else if (!my_storage) {
                //         creep.say("⏱");
                //         creep.moveTo(44,35);
                //     }
                    
                // }
                
            }
        } else {
            creep.say("💊");
            if ((creep.room + "").substr(6,6) == my_room) {
                creep.moveTo(34,22); //heal spot
            } else if ((creep.room + "").substr(6,6) != my_room) {
                functions.go_to(creep, my_room);
            }
            
        }  
        // if (creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)) {
        //     creep.say("🧱");
        //     const target = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        //     if(creep.build(target) == ERR_NOT_IN_RANGE) {
        //         creep.moveTo(target);
        //     } 
        
        
            
        // --miner_import logic end--
        
    }
};

module.exports = roleMiner_import;


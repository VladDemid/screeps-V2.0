var laborant_spot_x = 43,
    laborant_spot_y = 36, //место базирования
    laborant_spot = laborant_spot_x + "," + laborant_spot_y,
    labs_ids = ["5e3f1f36b5547d8108501805", "5e3f3dd442b53a34b01c2bc6", "5e3f2cfed9c0d0354696b434"],
    labs2_ids = ["5e415b8c6154df2e259bbea8", "5e4166671bfbaa2514a631cb", "5e414f07bc9a3065b577a4f1"],
    labs = [],
    labs2 = [];
    
    
    labs_funcs = require("labs_funcs");
    
var roleLaborant = {

    run: function(creep, my_storage, my_terminal, my_factory) {
        // --laborant logic start--
        for (var i = 0; i < labs_ids.length; i++) {
            labs[i] = Game.getObjectById(labs_ids[i]);
            labs2[i] = Game.getObjectById(labs2_ids[i]);
        }
        
        
        
        creep.say("🧪");
        
        if (creep.name.split('Laborant')[1] <= 1) {
            labs_funcs.make_reaction(creep, labs, "U", "L", "UL", 200, my_terminal);
        } else if (creep.name.split('Laborant')[1] <= 2) {
            labs_funcs.make_reaction(creep, labs2, "U", "L", "UL", 200, my_terminal);
        }
            // labs_funcs.make_reaction(creep, labs2, "Z", "K", "ZK", 200, my_terminal);
            // if (!creep.pos.isEqualTo(laborant_spot_x, laborant_spot_y)) {
            //     creep.moveTo(laborant_spot_x, laborant_spot_y);
            // }
            
            
            // labs_funcs.take_from_to(creep, "battery", my_factory,  my_terminal);
            
            
        //   if (my_storage.store["energy"] > 250000 && my_factory.store.getFreeCapacity() > 1000) {
        //         labs_funcs.bring_smth(creep, my_storage, "energy", my_factory, 5000);
        //         if (my_factory && my_factory.cooldown == 0 && my_factory.store["energy"] >= 600) {
        //             my_factory.produce("battery");
        //         }
        //     }
        
        
        
        
        
        
            
        
        
        // creep.transfer(my_terminal, "ZK");
        // creep.moveTo(43,37);
        // labs_funcs.bring_smth(creep, my_factory, "battery", my_terminal, 20350);
        
        // creep.moveTo(38,42);
        
        // --laborant logic end--
        
    }
};

module.exports = roleLaborant;



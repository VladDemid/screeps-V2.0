var enemy_found = false;

var roleTower_exp = {

    run: function(tower) {
        // --tower logic start--
        
        var enemy = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        
        if (enemy) {
            Game.notify('We were attacked at expansion: '+tower.pos, 2);
            tower.attack(enemy);
        } 
        
        // --tower logic end--
        
    }
};

module.exports = roleTower_exp;



//убивать сначала хилеров


// var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
//         filter: (i) => i.structureType == STRUCTURE_STORAGE &&
//                       i.store[RESOURCE_ENERGY] < 500000
//     });
var my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39",
    left_up_room = "W16S38",
    functions = require("functions");
    
var roleUpgrader_export = {

    run: function(creep) {
        // --upgrader_export logic start--
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                          i.store[RESOURCE_ENERGY] > 3000
        });
        
        var enemy_in_room = 0;
        if (creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS)) {
            enemy_in_room = 1;
        }
        
        if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.upgrading_now = true;
        }
        if (creep.carry.energy == 0) {
            creep.memory.upgrading_now = false;
        }
        
        var target_room;
        if (creep.name.split('Upgrader_export')[1] <= 1) {
            target_room = right_room;
        } else if (creep.name.split('Upgrader_export')[1] <= 2) {
            target_room = left_room;
        } else {
            target_room = left_up_room;
        }
        
        
        
        if (!enemy_in_room) {
            if (!creep.memory.upgrading_now) {
                if ((creep.room + "").substr(6,6) == my_room) {
                    creep.say("📥");
                    if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } else if ((creep.room + "").substr(6,6) != my_room) {
                    creep.say("🏠");
                    functions.go_to(creep, my_room);
                    if ((creep.room + "").substr(6,6) == "W16S38") {
                        creep.say("🏠!");
                        creep.moveTo(38,49);
                    }
                }
            } else if (creep.memory.upgrading_now) {
                if ((creep.room + "").substr(6,6) != target_room) {
                    creep.say("🚪🔋");
                    functions.go_to(creep, target_room);
                } else if ((creep.room + "").substr(6,6) == target_room) {
                    creep.say("🔋");
                    const controller = creep.room.controller;
                    if (controller.ticksToDowngrade < 19900 || controller.level < 3) { //чтобы на месте держать контроллер
                        if (creep.upgradeController(controller) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(controller);
                        }
                    } else {
                        creep.say("⏱");
                        creep.moveTo(controller);
                    }
                }
            }
        } else if (enemy_in_room) {
            creep.say('❗');
            var road = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                filter: (i) => i.structureType == STRUCTURE_ROAD
            });
            creep.moveTo(road);
        }
        
        
        // --upgrader_export logic end--
        
    }
};

module.exports = roleUpgrader_export;



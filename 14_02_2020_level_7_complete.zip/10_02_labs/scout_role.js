var start_room = "W15S39",
    target_room = "W19S40",
    scout_spot_x = 11,
    scout_spot_y = 47, //место базирования
    deposit_type = "metal",
    functions = require("functions");

var roleScout = {

    run: function(creep) {
        // --Scout logic start--
        
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
        
        // var mineral_type = creep.pos.findClosestByRange(FIND_MINERALS).mineralType, 
        
        //     extractor = creep.pos.findClosestByRange(FIND_STRUCTURES, {
        //     filter: (i) => i.structureType == STRUCTURE_EXTRACTOR 
                        
        // }),
        //     my_terminal = creep.pos.findClosestByRange(FIND_STRUCTURES, {
        //     filter: (i) => i.structureType == STRUCTURE_TERMINAL 
        //                 && i.store[mineral_type] < 15000
        // }),
            
        //     my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
        //     filter: (i) => i.structureType == STRUCTURE_STORAGE 
        //                 && i.store.getFreeCapacity() > 100000
        // });
        
        var my_room = functions.room_name(creep.room);
        
            enemy_building = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                filter: (i) => i.structureType != STRUCTURE_CONTROLLER 
                            
            });
        
        // target = Game.getObjectById("5dd6de273e316058b4be5988");
        var alive = true;
        if (creep.ticksToLive < 280) {
            alive = false;
        }
        if (!creep.memory.full) {
            if ((creep.room + "").substr(6,6) != target_room ) {
                if (alive) {
                    creep.say("🥾");
                    functions.scout_go(creep, target_room);
                } else if (!alive) {
                    creep.suicide();
                }
            } else if ((creep.room + "").substr(6,6) == target_room && alive) {
                const mineral_ore = creep.pos.findClosestByRange(FIND_DEPOSITS);
                if (mineral_ore) {
                    creep.say("💠");
                    if (creep.harvest(mineral_ore) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(mineral_ore);
                    }
                } else {
                    creep.moveTo(25,25);
                }
            } else if (!alive) {
                if (creep.store[deposit_type] > 0) {
                    creep.memory.full = true;
                } else {
                    creep.suicide();
                }
            }
        } else if (creep.memory.full) {
            if ((creep.room + "").substr(6,6) != start_room) {
                creep.say("🚪");
                functions.scout_go(creep, start_room);
            } else if ((creep.room + "").substr(6,6) == start_room) {
                var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    filter: (i) => i.structureType == STRUCTURE_STORAGE 
                                // && i.store.getFreeCapacity() > 100000
                    });
                    if (my_storage) {
                        creep.say("📦💠");
                        if(creep.transfer(my_storage, deposit_type) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(my_storage);
                        }
                    } else {
                        creep.moveTo(25,25);
                    }
                
            }
        }
        
        // --Scout logic end--
        
    }
};

module.exports = roleScout;



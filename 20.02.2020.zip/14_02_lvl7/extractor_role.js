var extractor_spot_x = 8,
    extractor_spot_y = 15; //место базирования

var roleExtractor = {

    run: function(creep) {
        // --defender logic start--
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
        
        var mineral_type = creep.pos.findClosestByRange(FIND_MINERALS).mineralType, 
        
            extractor = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_EXTRACTOR 
            }),
            
            my_terminal = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_TERMINAL 
                        && i.store[mineral_type] < 15000
            }),
            
            my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE 
                        && i.store.getFreeCapacity() > 100000
                        && i.store[mineral_type] < 100000
            }),
            
            escape_timer = 55;
        
        if (!creep.memory.full && extractor && creep.ticksToLive > escape_timer) {
            creep.say("☢️");
            const target = creep.pos.findClosestByRange(FIND_MINERALS);
            if(target && !target.ticksToRegeneration) {
                if(creep.harvest(target) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target);
                }
            } else if (target.ticksToRegeneration) {
                creep.say("☢️⏱");
                creep.moveTo(extractor_spot_x, extractor_spot_y);
            }
        } else if (my_terminal && creep.store[mineral_type] > 0) {
            creep.say("⚖️");
            if(creep.transfer(my_terminal, mineral_type) == ERR_NOT_IN_RANGE) {
                creep.moveTo(my_terminal);
            }
        }
        else if (my_storage && creep.store[mineral_type] > 0) {
            creep.say("☢️📦");
            if(creep.transfer(my_storage, mineral_type) == ERR_NOT_IN_RANGE) {
                creep.moveTo(my_storage);
            }
        } else {
            creep.moveTo(35,26);
        }
        
        // --defender logic end--
        
    }
};

module.exports = roleExtractor;



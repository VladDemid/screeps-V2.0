var linker_spot_x = 36,
    linker_spot_y = 35; //место базирования

var roleLinker = {

    run: function(creep, link_to, my_terminal, my_storage, help_need, extensions_mass) {
        // --linker logic start--
        
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
        
        if (!help_need) {
            if (!creep.memory.full) {
                if (link_to && link_to.store[RESOURCE_ENERGY] > 0) {
                    creep.say("🔷");
                    if(creep.withdraw(link_to, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(link_to);
                    }
                } else if (creep.store[RESOURCE_ENERGY] > 0) {
                    creep.memory.full = true;
                } else {
                    creep.say("🔎");
                    if (!creep.pos.isEqualTo(linker_spot_x, linker_spot_y)) { 
                        creep.moveTo(linker_spot_x, linker_spot_y);
                    }
                }
            } else if (creep.memory.full) {
                if (my_storage && my_storage.store[RESOURCE_ENERGY] < 200000) {
                    creep.say("📤");
                    if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } else if (my_terminal && my_terminal.store[RESOURCE_ENERGY] < 30000) {
                    creep.say("⚖️");   
                    if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_terminal);
                    }
                } else if (my_storage && my_storage.store[RESOURCE_ENERGY] < 700000) {
                    creep.say("📤");
                    if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } 
            } 
        } else if (help_need) {
            creep.say("🔹🧰");
            if (!creep.memory.full) {
                if (my_storage && my_storage.store["energy"] > 0) {
                    if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                }
            } else if (creep.memory.full) {
                // var spawn_structures = creep.pos.findClosestByRange(FIND_MY_STRUCTURES, {
                //     filter: (i) => i.structureType == STRUCTURE_EXTENSION
                //                 && i.store[RESOURCE_ENERGY] < i.store.getCapacity()
                // });
                if (extensions_mass && extensions_mass[0]) {
                    if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                    }
                }
            }
        }
        
        
                
            
        
        
        
        // --linker logic end--
        
    }
};

module.exports = roleLinker;



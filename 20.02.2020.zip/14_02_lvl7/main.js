var mining_max, upgrader_max, defender_max, fixer_max, healer_max, bastard_max, 
    miner_import_max, claimer_max, upgrader_export_max, defender_export_max, helper_max, 
    scout_max, builder_max, extractor_max, linker_max, carryer_max, laborant_max,
    spawning_lvl = 1,
    
    extensions_energy = 0,
    containers_energy = 0,
    
    functions = require("functions"),
    roleMiner = require("miner_role"),
    roleUpgrader = require("upgrader_role"),
    roleDefender = require("defender_role"),
    roleHealer = require("healer_role"),
    roleTower = require("tower_role"),
    roleTower_exp = require("tower_exp_role"),
    roleBastard = require("bastard_role"),
    roleMiner_import = require("miner_import_role"),
    roleClaimer = require("claimer_role"),
    roleUpgrader_export = require("upgrader_export_role"),
    roleDefender_export = require("defender_export_role"),
    roleHelper = require("helper_role"),
    roleFixer = require("fixer_role"),
    roleBuilder = require("builder_role"),
    roleExtractor = require("extractor_role"),
    roleLinker = require("linker_role"),
    roleCarryer = require("carryer_role"),
    roleScout = require("scout_role"),
    roleLaborant = require("laborant_role"),
    
    link_to_id = "5e32f3e2e9baddae3aabb44c",
    
    right_room = "W14S39",
    left_room = "W16S39";
    left_up_room = "W16S38";



module.exports.loop = function () {
    // console.log(Game.map.describeExits('W16S39')[7]);
    //определить в будущем spawning_lvl тут, и все mining_max... 
    var mining_count = 0,
        upgrader_count = 0,
        fixer_count = 0,
        miner_import_max = 0,
        defender_count = 0,
        healer_count = 0,
        bastard_count = 0,
        miner_import_count = 0,
        claimer_count = 0,
        upgrader_export_count = 0,
        defender_export_count = 0,
        helper_count = 0,
        scout_count = 0,
        builder_count = 0,
        linker_count = 0,
        carryer_count = 0,
        extractor_count = 0,
        laborant_count = 0,
        enemy_found = false;
    
    
    var extensions_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
        extensions_mass.sort((a,b) => a.energy - b.energy);
        for (var exs = 0; exs < extensions_mass.length; exs++) {
            extensions_energy = extensions_energy + extensions_mass[exs].energy;
        }
    
    var container_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
        container_mass.sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        for (var con = 0; con < container_mass.length; con++) {
            containers_energy = containers_energy + container_mass[con].store[RESOURCE_ENERGY];
        }
        
    var my_storage = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_STORAGE}});
    
    var my_terminal = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_TERMINAL 
        });    
        
    var my_factory = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_FACTORY 
        }); 
        
    var my_mineral = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_MINERALS);
        
    var towers_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
        towers_mass.sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        
    var tower_left_room = Game.rooms[left_room].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
    var tower_right_room = Game.rooms[right_room].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
    var tower_left_up_room = Game.rooms[left_up_room].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
    
    var link_from_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_LINK 
                        && i.id != link_to_id
        });
        
    var link_to = Game.getObjectById(link_to_id);
        
    var help_need = 1,
        found_helper = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_MY_CREEPS, {
            filter: (i) => i.memory.role == "helper"
        }); 
    if (found_helper) {help_need = 0;}
    
    var building_need = 1,
        found_builder = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_MY_CREEPS, {
            filter: (i) => i.memory.role == "builder"
        }); 
    if (found_builder) {building_need = 0;}
    
    var link_help_need = 1,
        found_linker = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_MY_CREEPS, {
            filter: (i) => i.memory.role == "linker"
        }); 
    if (found_linker) {link_help_need = 0;}
        
    
    if (Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS)) {
        enemy_found = true;
        // console.log("WAR!!",Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS).pos);
    }
    
    var ext_count = extensions_mass.length;
    if (ext_count) {
        if (ext_count <= 4) {
            spawning_lvl = 1;
        } else if (5 <= ext_count && ext_count <= 9) {
            spawning_lvl = 2;
        } else if (10 <= ext_count && ext_count <= 19) {
            spawning_lvl = 3;
        } else if (20 <= ext_count && ext_count <= 29) {
            spawning_lvl = 4;
        } else if (30 <= ext_count && ext_count <= 49) {
            spawning_lvl = 5;
        } else if (50 >= ext_count) {
            spawning_lvl = 6;
        }
    }
    
    switch (spawning_lvl) {
        case 1:
            mining_max = 5,
            defender_max = 3,
            upgrader_max = 1,
            fixer_max = 2,
            healer_max = 0,
            miner_import_max = 0;
            break;
        case 2:
            mining_max = 7,
            defender_max = 4,
            upgrader_max = 2,
            fixer_max = 2,
            healer_max = 1;
            break;
        case 3:
            mining_max = 7,
            defender_max = 4,
            upgrader_max = 1,
            fixer_max = 2,
            healer_max = 1,
            bastard_max = 1;
            break;
        case 4:
            mining_max = 2,
            defender_max = 0,
            upgrader_max = 5,
            fixer_max = 2,
            healer_max = 0,
            bastard_max = 1,
            miner_import_max = 7,
            claimer_max = 0,
            upgrader_export_max = 2,
            defender_export_max = 0,
            helper_max = 1,
            scout_max = 0;
            break;
        case 5:
            mining_max = 2,
            defender_max = 0,
            upgrader_max = 2,
            fixer_max = 2,
            healer_max = 0,
            bastard_max = 1,
            miner_import_max = 4,
            claimer_max = 0,
            upgrader_export_max = 3,
            defender_export_max = 2,
            helper_max = 1,
            builder_max = 0,
            extractor_max = 1,
            linker_max = 1,
            carryer_max = 6,
            laborant_max = 0,
            scout_max = 0;
            break;
        case 6:
            mining_max = 2,
            defender_max = 0,
            upgrader_max = 3,
            fixer_max = 2,
            healer_max = 0,
            bastard_max = 1,
            miner_import_max = 4,
            claimer_max = 0,
            upgrader_export_max = 3,
            defender_export_max = 2,
            helper_max = 1,
            builder_max = 0,
            extractor_max = 1,
            linker_max = 1,
            carryer_max = 6,
            laborant_max = 0,
            scout_max = 0;
            break;
    }
    
    if (my_mineral.mineralAmount == 0) {
        extractor_max = 0;
    }
    
    
    if (towers_mass) {
        for (i = 0; i < towers_mass.length; ++i) {
            roleTower.run(towers_mass[i], enemy_found);
        }
    }
    
    if (tower_left_room.length > 0) {
        roleTower_exp.run(tower_left_room[0]);
    }
    
    if (tower_right_room.length > 0) {
        roleTower_exp.run(tower_right_room[0]);
    }
    
    if (tower_left_up_room.length > 0) {
        roleTower_exp.run(tower_left_up_room[0]);
    }
    
    
    if (link_from_mass) {
        for (var i = 0; i < link_from_mass.length; i++) {
            // console.log(link_from_mass[i]);
            if (link_from_mass[i].store[RESOURCE_ENERGY] > 700 && link_to.store[RESOURCE_ENERGY] == 0 && link_from_mass[i].cooldown == 0) {
                link_from_mass[i].transferEnergy(link_to);
                break;
            }
        }
    }
    
    // if (my_storage && my_storage.store["energy"] > 200000 && my_terminal && my_terminal.store["energy"] > 2000 && Game.time % 15 == 0) {
    //     functions.market_deals(my_terminal);
    // }
    
    function spawn_start (spawner) { //порядок спавнов
    
        if (mining_count < mining_max) {
            functions.spawn_creep("Miner", mining_max, spawning_lvl, spawner);
        } else if (defender_count < defender_max) {
            functions.spawn_creep("Defender", defender_max, spawning_lvl, spawner);
        } else if (helper_count < helper_max) {
            functions.spawn_creep("Helper", helper_max, spawning_lvl, spawner);
        } else if (bastard_count < bastard_max) {
            functions.spawn_creep("Bastard", bastard_max, spawning_lvl, spawner);
        } else if (linker_count < linker_max) {
            functions.spawn_creep("Linker", linker_max, spawning_lvl, spawner);
        } else if (fixer_count < fixer_max) {
            functions.spawn_creep("Fixer", fixer_max, spawning_lvl, spawner);
        } else if (healer_count < healer_max) {
            functions.spawn_creep("Healer", healer_max, spawning_lvl, spawner);
        } else if (builder_count < builder_max) {
            functions.spawn_creep("Builder", builder_max, spawning_lvl, spawner);
        } else if (extractor_count < extractor_max) {
            functions.spawn_creep("Extractor", extractor_max, spawning_lvl, spawner);
        } else if (miner_import_count < miner_import_max) {
            functions.spawn_creep("Miner_import", miner_import_max, spawning_lvl, spawner);
        } else if (carryer_count < carryer_max) {
            functions.spawn_creep("Carryer", carryer_max, spawning_lvl, spawner);
        } else if (upgrader_count < upgrader_max) {
            functions.spawn_creep("Upgrader", upgrader_max, spawning_lvl, spawner);
        } else if (claimer_count < claimer_max) {
            functions.spawn_creep("Claimer", claimer_max, spawning_lvl, spawner);
        } else if (upgrader_export_count < upgrader_export_max) {
            functions.spawn_creep("Upgrader_export", upgrader_export_max, spawning_lvl, spawner);
        } else if (defender_export_count < defender_export_max) {
            functions.spawn_creep("Defender_export", defender_export_max, spawning_lvl, spawner);
        } else if (scout_count < scout_max) {
            functions.spawn_creep("Scout", scout_max, spawning_lvl, spawner);
        } else if (laborant_count < laborant_max) {
            functions.spawn_creep("Laborant", laborant_max, spawning_lvl, spawner);
        } 
        
        
        
    }
    
        
    for (var name in Game.creeps) {
        var creep = Game.creeps[name],
            creep_role = creep.memory.role;
        
            if (creep_role == "miner") {
                mining_count++;
                roleMiner.run(creep, spawning_lvl, extensions_energy, extensions_mass, 
                containers_energy, container_mass, my_storage, help_need, building_need);
            } else if (creep_role == "defender") {
                defender_count++;
                roleDefender.run(creep);
            } else if (creep_role == "fixer") {
                fixer_count++;
                roleFixer.run(creep);   
            } else if (creep_role == "healer") {
                healer_count++;
                roleHealer.run(creep);
            } else if (creep_role == "bastard") {
                bastard_count++;
                roleBastard.run(creep, container_mass, extensions_mass, towers_mass, enemy_found, 
                link_to, link_help_need);
            } else if (creep_role == "miner_import") {
                miner_import_count++;
                roleMiner_import.run(creep);
            } else if (creep_role == "upgrader") {
                upgrader_count++;
                roleUpgrader.run(creep);
            } else if (creep_role == "claimer") {
                claimer_count++;
                roleClaimer.run(creep);
            } else if (creep_role == "upgrader_export") {
                upgrader_export_count++;
                roleUpgrader_export.run(creep);
            } else if (creep_role == "defender_export") {
                defender_export_count++;
                roleDefender_export.run(creep);
            } else if (creep_role == "helper") {
                helper_count++;
                roleHelper.run(creep, extensions_energy, extensions_mass);
            } else if (creep_role == "scout") {
                scout_count++;
                roleScout.run(creep);
            } else if (creep_role == "builder") {
                builder_count++;
                roleBuilder.run(creep);
            } else if (creep_role == "extractor") {
                extractor_count++;
                roleExtractor.run(creep);
            } else if (creep_role == "linker") {
                linker_count++;
                roleLinker.run(creep, link_to, my_terminal, my_storage, help_need, extensions_mass);
            } else if (creep_role == "carryer") {
                carryer_count++;
                roleCarryer.run(creep, my_storage);
            } else if (creep_role == "laborant") {
                laborant_count++;
                roleLaborant.run(creep, my_storage, my_terminal, my_factory);
            }
            // отдельно проверка на врагов
            // if (enemy_found && creep_role != "defender" && creep_role != "bastard" 
            // && creep_role != "helper" && creep_role != "defender_export"
            // && creep_role != "upgrader_export" && creep_role != "scout") {
            //     creep.moveTo(38, 41);
            //     creep.say('❗');
            // }  //на случай войны
    }
    
    var spawner = "Spawn1";
    if (Game.spawns["Spawn1"].spawning && Game.spawns["Spawn2"]) {
        spawner = "Spawn2";
    }
    
    if (Game.spawns[spawner].spawning == null) {
        if (spawning_lvl == 1) { //дефолт
            if (Game.spawns.Spawn1.room.energyAvailable >= 300) {
                spawn_start();
            }
        } else if (spawning_lvl == 2) {
            if (Game.spawns.Spawn1.room.energyAvailable >= 550) {
                spawn_start();
            }
        } else if (spawning_lvl == 3) {
            if (Game.spawns.Spawn1.room.energyAvailable >= 800) {
                spawn_start();
            }
        } else if (spawning_lvl == 4) {
            if (Game.spawns.Spawn1.room.energyAvailable >= 1300) {
                spawn_start();
            }
        } else if (spawning_lvl == 5) {
            if (Game.spawns.Spawn1.room.energyAvailable >= 1800) {
                spawn_start(spawner);
            }
        } else if (spawning_lvl == 6) {
            if (Game.spawns.Spawn1.room.energyAvailable >= 5000) {
                spawn_start(spawner);
            }
        } 
    }
    
    functions.cpu_used();
    // console.log("After all cpu used: ", Game.cpu.getUsed().toFixed(2));
}





//чистить память Memory.creeps.*

var bastard_spot_x = 34,
    bastard_spot_y = 34, //место базирования
    resourse_mass = ["ZH", "LO", "KO", "UH", "GO", "K", "energy"];
    
    
var roleBastard = {

    run: function(creep, container_mass, extensions_mass, towers_mass, enemy_found, 
                  link_to, link_help_need) {
        // --bastard logic start--
        
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
        
        var tomb1 = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store["energy"] > 50 
            }),
        
            tomb_GO = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_GHODIUM_OXIDE] > 0 
            }),
        
            tomb_UH = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_UTRIUM_HYDRIDE] > 0 
            }),
        
            tomb_KO = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_KEANIUM_OXIDE] > 0 
            }),
        
            tomb_LO = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_LEMERGIUM_OXIDE] > 0 
            }),
        
            tomb_ZH = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
            filter: object => object.store[RESOURCE_ZYNTHIUM_HYDRIDE] > 0 
            }),
        
            ruin1 = creep.pos.findClosestByRange(FIND_RUINS, {
            filter: object => object.store[RESOURCE_ENERGY] > 0 
            }),
        
            my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                           i.store[RESOURCE_ENERGY] < 700000
            }),
            
            my_terminal = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_TERMINAL 
            }),
        
            drop1 = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES, {
            filter: object => object.amount > 50
            });
        
        if (!creep.memory.full) {
            if (tomb_UH) {
                creep.say("⚰️💎");
                if(creep.withdraw(tomb_UH, RESOURCE_UTRIUM_HYDRIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb_UH);
                }
            } else if (tomb_KO) {
                creep.say("⚰️💎");
                if(creep.withdraw(tomb_KO, RESOURCE_KEANIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb_KO);
                }
            } else if (tomb_LO) {
                creep.say("⚰️💎");
                if(creep.withdraw(tomb_LO, RESOURCE_LEMERGIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb_LO);
                }
            } else if (tomb_ZH) {
                creep.say("⚰️💎");
                if(creep.withdraw(tomb_ZH, RESOURCE_ZYNTHIUM_HYDRIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb_ZH);
                }
            } else if (tomb_GO) {
                creep.say("⚰️💎");
                if(creep.withdraw(tomb_GO, RESOURCE_GHODIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb_GO);
                }
            }
            
            else if (tomb1 && !enemy_found) {
                creep.say("⚰️");
                if(creep.withdraw(tomb1, "energy") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb1);
                }
            } else if (drop1) {
                creep.say("💎");
                if(creep.pickup(drop1) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(drop1);
                }
            } else if (ruin1) {
                creep.say("🏺");
                if(creep.withdraw(ruin1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(ruin1);
                }
            } else if (towers_mass.length && towers_mass[0].store[RESOURCE_ENERGY] < 1000 && my_storage && my_storage.store[RESOURCE_ENERGY] > 0) {
                creep.say("📥");
                if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (link_to && link_to.store[RESOURCE_ENERGY] > 0 && link_help_need) {
                creep.say("🔷");
                if(creep.withdraw(link_to, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(link_to);
                }
            } 
            
            // else if (my_terminal && creep.carry.energy < creep.carryCapacity && creep.carry.energy > 0) {
            //     creep.say("⚖️");  
            //     if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(my_terminal);
            //     }
            // } 
            
            //
            // else if (my_storage && creep.carry.energy < creep.carryCapacity && creep.carry.energy > 0) {
            //     creep.say("📤");
            //     if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(my_storage);
            //     }
            // } 
            // else if (container_mass.length && container_mass[0].store[RESOURCE_ENERGY] < 2000 && my_storage && my_storage.store[RESOURCE_ENERGY] > 0) {
            //     creep.say("📥");
            //     if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         creep.moveTo(my_storage);
            //     }
            // } 
              else if (creep.store.getFreeCapacity() < creep.carryCapacity) {
                creep.memory.full = true;
            } else {
                creep.say("🔍");
                if (!creep.pos.isEqualTo(bastard_spot_x, bastard_spot_y)) { 
                    creep.moveTo(bastard_spot_x, bastard_spot_y);
                }
            }
            
        } else if (creep.memory.full) {
            creep.say("📤");
            // проверка если есть химикаты
            
            // for (var i = 0; i < resourse_mass.length;i++) {
            //     if (creep.store[resourse_mass[i]] > 0) {
            //         console.log(resourse_mass[i], " carrying");
            //         // if(creep.transfer(my_storage, RESOURCE_GHODIUM_OXIDE) == ERR_NOT_IN_RANGE) {
            //         //     creep.moveTo(my_storage);
            //         // }
            //     }
            // }
            
            if (creep.store[RESOURCE_GHODIUM_OXIDE] > 0) {
                creep.say("🧪");
                if(creep.transfer(my_storage, RESOURCE_GHODIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (creep.store[RESOURCE_UTRIUM_HYDRIDE] > 0) {
                creep.say("🧪");
                if(creep.transfer(my_storage, RESOURCE_UTRIUM_HYDRIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (creep.store[RESOURCE_KEANIUM_OXIDE] > 0) {
                creep.say("🧪");
                if(creep.transfer(my_storage, RESOURCE_KEANIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (creep.store[RESOURCE_LEMERGIUM_OXIDE] > 0) {
                creep.say("🧪");
                if(creep.transfer(my_storage, RESOURCE_LEMERGIUM_OXIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (creep.store[RESOURCE_ZYNTHIUM_HYDRIDE] > 0) {
                creep.say("🧪");
                if(creep.transfer(my_storage, RESOURCE_ZYNTHIUM_HYDRIDE) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (creep.store["K"] > 0) {
                creep.say("☢️");
                if(creep.transfer(my_storage, "K") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } else if (towers_mass.length && towers_mass.length > 0 && towers_mass[0].store[RESOURCE_ENERGY] < 1000) {
                creep.say("🔭⚡️");
                if(creep.transfer(towers_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(towers_mass[0]);
                }
            } else if (container_mass.length && container_mass[0].store[RESOURCE_ENERGY] < 2000) {
                creep.say("📒");   
                if(creep.transfer(container_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(container_mass[0]);
                }
            } else if (my_terminal && my_terminal.store[RESOURCE_ENERGY] < 20000) {
                creep.say("⚖️");   
                if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_terminal);
                }
            } else if (my_storage) {
                creep.say("📤");
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_storage);
                }
            } 
            else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.full = false;
            } else {
                if (!creep.pos.isEqualTo(bastard_spot_x, bastard_spot_y)) { 
                    creep.moveTo(bastard_spot_x, bastard_spot_y);
                }
            }
        }
        
        // --bastard logic end--
        
    }
};

module.exports = roleBastard;



        
//         if(ruin1) {
//             if(creep.withdraw(ruin1, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
//                 creep.moveTo(ruin1);
//             }
//         }


//FIND_DROPPED_RESOURCES
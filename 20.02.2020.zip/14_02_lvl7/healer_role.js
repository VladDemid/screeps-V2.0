var healer_spot_x = 38,
    healer_spot_y = 31; //место базирования

var roleHealer = {

    run: function(creep) {
        // --healer logic start--
        const target = creep.pos.findClosestByRange(FIND_MY_CREEPS, {
            filter: function(object) {
                return object.hits < object.hitsMax;
            }
        });
        
        
        if(target) {
            creep.say("💉");
            if(creep.heal(target) == ERR_NOT_IN_RANGE) {
                creep.moveTo(target);
            }
        }else {
            creep.moveTo(healer_spot_x, healer_spot_y)
            creep.say("🚬");
        }
        
        // --healer logic end--
        
    }
};

module.exports = roleHealer;



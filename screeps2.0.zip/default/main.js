var mining_max, upgrader_max, defender_max, fixer_max, healer_max, bastard_max,
    spawning_lvl = 1,
    
    extensions_energy = 0,
    containers_energy = 0,
    
    functions = require("functions"),
    roleMiner = require("miner_role"),
    roleUpgrader = require("upgrader_role"),
    roleDefender = require("defender_role"),
    roleHealer = require("healer_role"),
    roleTower = require("tower_role"),
    roleBastard = require("bastard_role"),
    roleFixer = require("fixer_role");
    


module.exports.loop = function () {
    
    //определить в будущем spawning_lvl тут, и все mining_max... 
    var mining_count = 0,
        upgrader_count = 0,
        fixer_count = 0,
        defender_count = 0,
        healer_count = 0,
        bastard_count = 0,
        enemy_found = false;
    
    var extensions_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
        extensions_mass.sort((a,b) => a.energy - b.energy);
        for (var exs = 0; exs < extensions_mass.length; exs++) {
            extensions_energy = extensions_energy + extensions_mass[exs].energy;
        }
    
    var container_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
        container_mass.sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        for (var con = 0; con < container_mass.length; con++) {
            containers_energy = containers_energy + container_mass[con].store[RESOURCE_ENERGY];
        }
    
    
        
    // console.log(container_mass.length, containers_energy);
        
    var towers_mass = Game.spawns['Spawn1'].room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
        towers_mass.sort((a,b) => a.store.getFreeCapacity - b.store.getFreeCapacity);
        //как будет 2 турели перепроверить сортировку
    
    if (Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS)) {
        enemy_found = true;
        // console.log("WAR!!",Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS).pos);
    }
    
    var ext_count = extensions_mass.length;
    if (ext_count) {
        if (5 <= ext_count && ext_count <= 9) {
            spawning_lvl = 2;
        } else if (10 <= ext_count && ext_count <= 14) {
            spawning_lvl = 3;
        }
    }
    
    switch (spawning_lvl) {
        case 1:
            mining_max = 6,
            defender_max = 3,
            upgrader_max = 1,
            fixer_max = 2,
            healer_max = 0;
            break;
        case 2:
            mining_max = 7,
            defender_max = 4,
            upgrader_max = 2,
            fixer_max = 2,
            healer_max = 1;
            break;
        case 3:
            mining_max = 6,
            defender_max = 4,
            upgrader_max = 3,
            fixer_max = 2,
            healer_max = 1,
            bastard_max = 1;
            break;
    }
    
    if (towers_mass) {
        for (i = 0; i < towers_mass.length; ++i) {
            roleTower.run(towers_mass[i], enemy_found);
        }
    }
    
    function spawn_start () {
        if (mining_count < mining_max) {
            console.log("--MINING spawn--");
            functions.spawn_creep("Miner", mining_max, spawning_lvl);
        } else if (defender_count < defender_max) {
            console.log("--DEFENDER spawn--");
            functions.spawn_creep("Defender", defender_max, spawning_lvl);
        } else if (upgrader_count < upgrader_max) {
            console.log("--UPGRADER spawn--");
            functions.spawn_creep("Upgrader", upgrader_max, spawning_lvl);
        } else if (fixer_count < fixer_max) {
            console.log("--FIXER spawn--");
            functions.spawn_creep("Fixer", fixer_max, spawning_lvl);
        } else if (healer_count < healer_max) {
            console.log("--Healer spawn--");
            functions.spawn_creep("Healer", healer_max, spawning_lvl);
        } else if (bastard_count < bastard_max) {
            console.log("--Bastard spawn--");
            functions.spawn_creep("Bastard", bastard_max, spawning_lvl);
        }
    }
    // console.log("-------------");
    // console.log("before creeps cpu used: ", Game.cpu.getUsed().toFixed(2));
    for (var name in Game.creeps) {
        var creep = Game.creeps[name],
            creep_role = creep.memory.role;
        
            if (creep_role == "miner") {
                mining_count++;
                roleMiner.run(creep, spawning_lvl, extensions_energy, extensions_mass, containers_energy, container_mass);
            } else if (creep_role == "defender") {
                defender_count++;
                roleDefender.run(creep);
            } else if (creep_role == "upgrader") {
                upgrader_count++;
                roleUpgrader.run(creep);
            } else if (creep_role == "fixer") {
                fixer_count++;
                roleFixer.run(creep);   
            } else if (creep_role == "healer") {
                healer_count++;
                roleHealer.run(creep);
            } else if (creep_role == "bastard") {
                bastard_count++;
                roleBastard.run(creep, container_mass, extensions_mass, towers_mass);
            }
            // отдельно проверка на врагов
            if (enemy_found && (creep_role == "upgrader" || creep_role == "fixer")) {
                creep.moveTo(36, 36);
                creep.say('❗');
            }
    }
    // console.log("after creeps cpu used: ", Game.cpu.getUsed().toFixed(2));
    if (spawning_lvl == 1) { //дефолт
        if (Game.spawns.Spawn1.room.energyAvailable >= 300) {
            spawn_start();
        }
    } else if (spawning_lvl == 2) {
        if (Game.spawns.Spawn1.room.energyAvailable >= 550) {
            spawn_start();
        }
    } else if (spawning_lvl == 3) {
        if (Game.spawns.Spawn1.room.energyAvailable >= 800) {
            spawn_start();
        }
    }
    // functions.cpu_used();
    // console.log("After all cpu used: ", Game.cpu.getUsed().toFixed(2));
}





//чистить память Memory.creeps.*

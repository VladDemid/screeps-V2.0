var healer_spot_x = 38,
    healer_spot_y = 30; //место базирования

var roleTower = {

    run: function(tower, enemy_found) {
        // --tower logic start--
        
        if (enemy_found) {
            const target = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            tower.attack(target);
        }
        
        
        // --tower logic end--
        
    }
};

module.exports = roleTower;



//убивать сначала хилеров
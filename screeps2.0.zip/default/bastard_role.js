var bastard_spot_x = 30,
    bastard_spot_y = 35; //место базирования

var roleBastard = {

    run: function(creep, container_mass, extensions_mass, towers_mass) {
        // --bastard logic start--
        
        if (creep.carry.energy == 0) {creep.memory.bastarding = false;}
        if (creep.carry.energy == creep.carryCapacity) {creep.memory.bastarding = true;}
        
        if (!creep.memory.bastarding) {
            creep.say("📥");
            if(creep.withdraw(container_mass[container_mass.length - 1], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                creep.moveTo(container_mass[container_mass.length - 1]);
            }
        } else if (creep.memory.bastarding) {
            creep.say("📤");
            if (creep.room.energyAvailable < creep.room.energyCapacityAvailable /*&& !(creep.name.split('Miner')[1] % 6 == 0)*/) {
                if (Game.spawns.Spawn1.store[RESOURCE_ENERGY] < 300) { 
                    creep.say("🚛");
                    if (creep.transfer(Game.spawns['Spawn1'], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(Game.spawns['Spawn1']);
                    }
                } else if (extensions_mass && extensions_mass[0].energy < extensions_mass[0].energyCapacity) {
                    // console.log("extensions energy low");
                    creep.say("📀");
                    const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                    if  (range_1_str) {
                        for (var y = 0; y < range_1_str.length;y++) {
                            if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                                creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                                creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                            }
                        }
                    } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(extensions_mass[0]);
                    }
                    if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                    } 
                } 
            } else if (towers_mass && towers_mass.length > 0 && towers_mass[0].store[RESOURCE_ENERGY] < 1000) {
                if(creep.transfer(towers_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(towers_mass[0]);
                }
            } else if (creep.carry.energy < creep.carryCapacity) {
                creep.memory.bastarding = false;
            } else {
                creep.moveTo(bastard_spot_x, bastard_spot_y);
            }
        }
        
        // --bastard logic end--
        
    }
};

module.exports = roleBastard;





//FIND_DROPPED_RESOURCES
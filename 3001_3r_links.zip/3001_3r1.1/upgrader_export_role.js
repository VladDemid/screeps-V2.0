var my_room = "W15S39",
    right_room = "W14S39",
    left_room = "W16S39";
    
var roleUpgrader_export = {

    run: function(creep) {
        // --upgrader_export logic start--
        
        var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (i) => i.structureType == STRUCTURE_STORAGE &&
                          i.store[RESOURCE_ENERGY] > 3000
        });
        
        var enemy_in_room = 0;
        if (creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS)) {
            enemy_in_room = 1;
        }
        
        if (creep.carry.energy == creep.carryCapacity) {
            creep.memory.upgrading_now = true;
        }
        if (creep.carry.energy == 0) {
            creep.memory.upgrading_now = false;
        }
        
        var target_room;
        if (creep.name.split('Upgrader_export')[1] <= 2) {
            target_room = right_room;
        } else {
            target_room = left_room;
        }
        
        if ((creep.room + "").substr(6,6) == my_room) {
            if (!enemy_in_room) {
                if (!creep.memory.upgrading_now) {
                    creep.say("📥");
                    if(creep.withdraw(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                } else if (creep.memory.upgrading_now) {
                    creep.say("🚪🔋");
                    const route = Game.map.findRoute(creep.room, target_room);
                    if(route.length > 0) {
                        const exit = creep.pos.findClosestByRange(route[0].exit);
                        creep.moveTo(exit);
                    }
                }
            } else if (enemy_in_room) {
                creep.say('❗');
                creep.moveTo(Game.spawns['Spawn1'])
            }
        } else if ((creep.room + "").substr(6,6) == target_room) {
            if (!enemy_in_room) {
                if (creep.memory.upgrading_now) {
                    creep.say("🔋");
                    var controller = creep.room.controller;
                    if (creep.upgradeController(controller) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(controller);
                    }
                } else if (!creep.memory.upgrading_now) {
                    const route = Game.map.findRoute(creep.room, my_room);
                    if(route.length > 0) {
                        const exit = creep.pos.findClosestByRange(route[0].exit);
                        creep.moveTo(exit);
                    }
                }
            } else if (enemy_in_room) {
                creep.say('❗');
                var road = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    filter: (i) => i.structureType == STRUCTURE_ROAD
                });
                creep.moveTo(road);
            }
        }
        
        // --upgrader_export logic end--
        
    }
};

module.exports = roleUpgrader_export;



var healer_spot_x = 38,
    healer_spot_y = 30; //место базирования

var roleTower = {

    run: function(tower, enemy_found) {
        // --tower logic start--
        
        
        if (enemy_found) {
            Game.notify('We were attacked ', 2);
            // const healer_creep = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
            //     filter: (i) => i.body.toString().indexOf("HEAL") != -1 
            // });
            const target = Game.spawns['Spawn1'].pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            const target_healer = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS, {
                filter: function(object) {
                    return object.getActiveBodyparts(HEAL) >= 1;
                }
            });
            
           
            if (target) {
                tower.attack(target);
            }
            
        } else if (!enemy_found) {
            const target = tower.pos.findClosestByRange(FIND_MY_CREEPS, {
                filter: function(object) {
                    return object.hits < object.hitsMax;
                }
            });
            if (target) {
                tower.heal(target);
            }
        }
        
        // console.log("find_work_creep ", find_work_creep);
        
        
        // --tower logic end--
        
    }
};

module.exports = roleTower;



//убивать сначала хилеров


// var my_storage = creep.pos.findClosestByRange(FIND_STRUCTURES, {
//         filter: (i) => i.structureType == STRUCTURE_STORAGE &&
//                       i.store[RESOURCE_ENERGY] < 500000
//     });
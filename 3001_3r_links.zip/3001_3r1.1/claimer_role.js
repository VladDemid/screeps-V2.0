var my_room = "W15S39",
    right_room = "W14S39";
    
    
var roleClaimer = {

    run: function(creep) {
        // --Claimer logic start--
        
         if ((creep.room + "").substr(6,6) == my_room) {
                creep.say("🧲");
                const route = Game.map.findRoute(creep.room, right_room);
                if(route.length > 0) {
                    const exit = creep.pos.findClosestByRange(route[0].exit);
                    creep.moveTo(exit);
                }
            } else if ((creep.room + "").substr(6,6) == right_room) {
                creep.say("🧲");
                if(creep.room.controller) {
                    if(creep.claimController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(creep.room.controller);
                    }
                }
            } 
        
        // --Claimer logic end--
        
    }
};

module.exports = roleClaimer;


